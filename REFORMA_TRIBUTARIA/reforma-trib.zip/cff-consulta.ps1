<#
.SYNOPSIS
  Busca classTrib (JSON) no serviço CFF usando certificado do Windows Certificate Store (CurrentUser/LocalMachine)
  e permite seleção interativa a partir de uma lista resumida (nome/CNPJ/expiração).

.DESCRIPTION
  - Compatível com PowerShell 5.1.
  - Lista os certificados de forma resumida (Index | Nome / CN | Documento (CNPJ/CPF) | Expiração | HasKey).
  - Permite selecionar por número ou colando thumbprint.
  - Mantém suporte a filtros, seleção por thumbprint e gravação de resposta JSON em UTF-8 sem BOM.
  - Força TLS1.2.

.PARAMETER Thumbprint
  Thumbprint do certificado (opcional). Se não informado, o script entra em modo interativo para seleção.

.PARAMETER StoreLocation
  CurrentUser (default) ou LocalMachine.

.PARAMETER Url
  URL da consulta (default: https://cff.svrs.rs.gov.br/api/v1/consultas/classTrib).

.PARAMETER Cst
  Filtro Cst.

.PARAMETER NomeCst
  Filtro NomeCst.

.PARAMETER Output
  Caminho do arquivo de saída (default: classTrib_response.json).

.PARAMETER Force
  Sobrescreve Output sem pedir confirmação.

.PARAMETER Filter
  Texto para filtrar a lista de certificados (por Subject / FriendlyName / Thumbprint).

.EXAMPLE
  # Interativo (lista resumida + seleção)
  & .\fetch_classTrib_store_ps51.ps1 -StoreLocation CurrentUser -Output "G:\cclasstrib\classTrib.json"

  # Passando thumbprint direto (não interativo)
  & .\fetch_classTrib_store_ps51.ps1 -Thumbprint "C945..." -StoreLocation CurrentUser -Output "G:\cclasstrib\classTrib.json"
#>

param(
  [Parameter(Mandatory=$false)][string]$Thumbprint,
  [ValidateSet("CurrentUser","LocalMachine")][string]$StoreLocation = "CurrentUser",
  [string]$Url = "https://cff.svrs.rs.gov.br/api/v1/consultas/classTrib",
  [string]$Cst,
  [string]$NomeCst,
  [string]$Output = "classTrib_response.json",
  [switch]$Force,
  [string]$Filter
)

# Forçar TLS1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function Write-Info([string]$msg) { Write-Host $msg -ForegroundColor Cyan }
function Write-Warn([string]$msg) { Write-Host $msg -ForegroundColor Yellow }
function Write-Err([string]$msg) { Write-Host $msg -ForegroundColor Red }

# Monta URI com filtros
if ($Cst) {
  $uri = "$Url?Cst=$Cst"
} elseif ($NomeCst) {
  $uri = "$Url?NomeCst=$( [uri]::EscapeDataString($NomeCst) )"
} else {
  $uri = $Url
}

# Extrai CN e documento (CNPJ/CPF) de um certificado
function Get-CertDisplayInfo {
    param([System.Security.Cryptography.X509Certificates.X509Certificate2]$Cert)
    $display = $null
    if ($Cert.FriendlyName -and $Cert.FriendlyName.Trim().Length -gt 0) {
        $display = $Cert.FriendlyName
    } else {
        if ($Cert.Subject) {
            $m = [regex]::Match($Cert.Subject, 'CN=([^,]+)')
            if ($m.Success) { $display = $m.Groups[1].Value.Trim() }
            else { $display = $Cert.Subject }
        } else {
            $display = "<sem subject>"
        }
    }

    # Tentar extrair documento (CNPJ 14 dígitos ou CPF 11)
    $doc = ""
    if ($Cert.Subject) {
        $m14 = ([regex]'\d{14}').Match($Cert.Subject)
        $m11 = ([regex]'\d{11}').Match($Cert.Subject)
        if ($m14.Success) { $doc = $m14.Value }
        elseif ($m11.Success) { $doc = $m11.Value }
        else {
            if ($Cert.FriendlyName) {
                $m14f = ([regex]'\d{14}').Match($Cert.FriendlyName)
                $m11f = ([regex]'\d{11}').Match($Cert.FriendlyName)
                if ($m14f.Success) { $doc = $m14f.Value }
                elseif ($m11f.Success) { $doc = $m11f.Value }
            }
        }
    }

    return @{ DisplayName = $display; Doc = $doc }
}

# Função que mostra lista resumida e permite seleção
function Select-CertificateFromStore {
    param(
        [ValidateSet("CurrentUser","LocalMachine")][string]$StoreLoc,
        [string]$TextFilter
    )

    $storePath = "Cert:\$StoreLoc\My"
    try {
        $certs = Get-ChildItem -Path $storePath -ErrorAction Stop
    } catch {
        Write-Err ("Falha ao abrir o store ${storePath}: {0}" -f $_)
        return $null
    }

    if ([string]::IsNullOrWhiteSpace($TextFilter) -eq $false) {
        $text = $TextFilter.ToLower()
        $certs = $certs | Where-Object {
            ($_.Subject -and $_.Subject.ToLower().Contains($text)) -or
            ($_.FriendlyName -and $_.FriendlyName.ToLower().Contains($text)) -or
            ($_.Thumbprint -and $_.Thumbprint.ToLower().Contains($text))
        }
    }

    if (-not $certs -or $certs.Count -eq 0) {
        Write-Warn "Nenhum certificado encontrado em ${storePath} (após filtro)."
        return $null
    }

    # Preparar objetos resumidos
    $list = @()
    foreach ($c in $certs) {
        $info = Get-CertDisplayInfo -Cert $c
        $shortThumb = if ($c.Thumbprint) { 
            if ($c.Thumbprint.Length -ge 8) { $c.Thumbprint.Substring($c.Thumbprint.Length - 8) } else { $c.Thumbprint } 
        } else { "" }
        $obj = [PSCustomObject]@{
            Index = 0
            Name  = $info.DisplayName
            Doc   = $info.Doc
            Expiry = if ($c.NotAfter) { $c.NotAfter.ToString('yyyy-MM-dd') } else { "" }
            HasKey = if ($c.HasPrivateKey) { 'S' } else { 'N' }
            ThumbShort = $shortThumb
            ThumbFull = $c.Thumbprint
            RawCert = $c
        }
        $list += $obj
    }

    # Ordena por Expiry (data) e depois Name; tratar expirations vazias colocando MaxValue
    $sorted = $list | Sort-Object -Property @{
        Expression = {
            if ([string]::IsNullOrWhiteSpace($_.Expiry)) {
                # colocar no final
                [datetime]::MaxValue
            } else {
                try { [datetime]::ParseExact($_.Expiry,'yyyy-MM-dd',$null) } catch { [datetime]::MaxValue }
            }
        }
    }, @{
        Expression = { $_.Name }
    }

    # Atribui índices
    $idx = 1
    foreach ($s in $sorted) { $s.Index = $idx; $idx++ }

    # Mostrar tabela resumida (Name truncated, Doc, Expiry, HasKey, Thumb short)
    Write-Host ""
    Write-Host ("{0,4} {1,-40} {2,-14} {3,-10} {4,-4} {5}" -f "No.", "Nome / CN", "Documento", "Expiração", "Key", "Thumb...")
    Write-Host ("{0,4} {1,-40} {2,-14} {3,-10} {4,-4} {5}" -f "----","----------------------------------------","--------------","----------","----","--------")
    foreach ($s in $sorted) {
        $name = $s.Name
        if ($name.Length -gt 40) { $name = $name.Substring(0,37) + "..." }
        $doc = if ($s.Doc) { $s.Doc } else { "" }
        Write-Host ("{0,4} {1,-40} {2,-14} {3,-10} {4,-4} {5}" -f $s.Index, $name, $doc, $s.Expiry, $s.HasKey, $s.ThumbShort)
    }

    while ($true) {
        $sel = Read-Host "Digite o número do certificado (ou cole o thumbprint). 'q' para cancelar"
        if ($sel -eq 'q') { return $null }
        $nullRef = $null
        $ok = [int]::TryParse($sel, [ref]$nullRef)
        if ($ok) {
            $idx = [int]$sel
            $found = $sorted | Where-Object { $_.Index -eq $idx }
            if ($found) { return $found.RawCert }
            else { Write-Warn "Índice inválido. Informe um número entre 1 e $($sorted.Count)." }
        } else {
            # verificar thumbprint (aceita colagem completa)
            $tp = $sel -replace '\s',''
            $found = $sorted | Where-Object { $_.ThumbFull -eq $tp -or $_.ThumbFull -eq $tp.ToUpper() -or $_.ThumbFull -eq $tp.ToLower() }
            if ($found) { return $found.RawCert }
            else { Write-Warn "Thumbprint não encontrado na lista (tente novamente)." }
        }
    }
}

# Obtém o certificado: por thumbprint ou por seleção interativa
$cert = $null
$storePath = "Cert:\$StoreLocation\My"
if (-not [string]::IsNullOrWhiteSpace($Thumbprint)) {
    try {
        $cert = Get-ChildItem -Path $storePath | Where-Object { $_.Thumbprint -eq $Thumbprint -or $_.Thumbprint -eq $Thumbprint.ToUpper() } 
    } catch {
        Write-Err ("Falha ao buscar certificado por thumbprint em ${storePath}: {0}" -f $_)
        exit 1
    }
    if (-not $cert) {
        Write-Warn "Certificado com thumbprint $Thumbprint não encontrado em ${storePath}."
        $trySelect = Read-Host "Deseja selecionar um certificado do store interativamente? (s/n)"
        if ($trySelect -and $trySelect.ToLower().StartsWith('s')) {
            $cert = Select-CertificateFromStore -StoreLoc $StoreLocation -TextFilter $Filter
        } else {
            exit 2
        }
    }
} else {
    # nenhum thumbprint: selecionar interativamente (lista resumida)
    $cert = Select-CertificateFromStore -StoreLoc $StoreLocation -TextFilter $Filter
}

if (-not $cert) {
    Write-Err "Nenhum certificado selecionado. Abortando."
    exit 2
}

# Validações
Write-Info "Usando certificado selecionado:"
Write-Host "  Subject      : $($cert.Subject)"
Write-Host "  Thumbprint   : $($cert.Thumbprint)"
Write-Host "  FriendlyName : $($cert.FriendlyName)"
Write-Host "  NotBefore    : $($cert.NotBefore)"
Write-Host "  NotAfter     : $($cert.NotAfter)"
Write-Host "  HasPrivateKey: $($cert.HasPrivateKey)"

if (-not $cert.HasPrivateKey) {
    Write-Warn "O certificado selecionado não possui chave privada acessível. mTLS geralmente requer a chave privada."
    $cont = Read-Host "Deseja continuar mesmo assim? (s/N)"
    if (-not $cont -or $cont.ToLower().StartsWith('s') -eq $false) {
        Write-Err "Abortando por falta de chave privada."
        exit 3
    }
}

# Verifica expiracao
if ($cert.NotAfter -lt (Get-Date)) {
    Write-Warn "Atenção: certificado expirado em $($cert.NotAfter). Deseja continuar? (s/N)"
    $cont2 = Read-Host
    if (-not $cont2 -or $cont2.ToLower().StartsWith('s') -eq $false) {
        Write-Err "Abortando por certificado expirado."
        exit 4
    }
}

# Confirma overwrite do arquivo de saída
if ((Test-Path $Output) -and (-not $Force)) {
    $ans = Read-Host "Arquivo '$Output' já existe. Deseja sobrescrever? (s/N)"
    if (-not $ans -or $ans.ToLower().StartsWith('s') -eq $false) {
        Write-Err "Abortando para evitar sobrescrita."
        exit 7
    }
}

# Cria request usando HttpWebRequest e anexa o certificado
try {
    $req = [System.Net.WebRequest]::Create($uri)
    $req = [System.Net.HttpWebRequest]$req
    $req.Method = "GET"
    $req.Accept = "application/json"
    $req.ClientCertificates.Add($cert)
    $req.Timeout = 60000
} catch {
    Write-Err ("Erro criando HttpWebRequest: {0}" -f $_)
    exit 5
}

# Executa e grava resposta
try {
    Write-Info "Requisitando: $uri"
    $resp = $req.GetResponse()
    $statusDesc = $resp.StatusDescription
    $statusCode = [int]$resp.StatusCode
    Write-Info "Status: $statusCode $statusDesc"
    $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
    $body = $sr.ReadToEnd()
    # salva resposta (JSON) em UTF8 sem BOM
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($Output, $body, $utf8NoBom)
    Write-Host "Resposta salva em: $Output"
    exit 0
} catch [System.Net.WebException] {
    $we = $_.Exception
    if ($we.Response) {
        $httpResp = $we.Response
        $code = [int]$httpResp.StatusCode
        $text = (New-Object System.IO.StreamReader($httpResp.GetResponseStream())).ReadToEnd()
        Write-Err "Resposta HTTP de erro: $code"
        Write-Host $text
        # salva corpo de erro para análise
        try { $text | Out-File -FilePath $Output -Encoding UTF8 } catch {}
        exit 6
    } else {
        Write-Err ("WebException sem resposta: {0}" -f $_.Exception.Message)
        exit 8
    }
} catch {
    Write-Err ("Erro inesperado: {0}" -f $_)
    exit 9
}