# Uso rápido — cff-consulta.ps1

Resumo curto
- Script PowerShell (compatível com PowerShell 5.1) para baixar o JSON de classTrib do serviço CFF usando mTLS com um certificado do Windows Certificate Store.
- Permite selecionar o certificado interativamente ou informar o thumbprint diretamente.
- Salva a resposta JSON em UTF‑8 (sem BOM).

Requisitos
- PowerShell 5.1 (Windows).
- Acesso à chave privada do certificado (execute como o usuário que tem permissão).
- Conexão com a URL padrão: https://cff.svrs.rs.gov.br/api/v1/consultas/classTrib

Principais parâmetros
- `-Thumbprint "<thumbprint>"` — opcional; se omitido, o script abre seleção interativa.
- `-StoreLocation CurrentUser|LocalMachine` — local do store (default: CurrentUser).
- `-Output "<arquivo.json>"` — caminho do arquivo de saída (default: classTrib_response.json).
- `-Cst "<valor>"` ou `-NomeCst "<texto>"` — filtros aplicados à URL.
- `-Force` — sobrescreve arquivo de saída sem pedir confirmação.
- `-Filter "<texto>"` — filtra a lista de certificados por Subject/FriendlyName/Thumbprint.
- `-EnableUtf8Console` — tenta ativar codificação UTF‑8 no console (melhora acentos; opcional).
- UI por padrão em inglês e sem acentos (para evitar problemas de exibição).

Como usar (exemplos)
- Seleção interativa (default):
  ```
  .\cff-consulta.ps1 -StoreLocation CurrentUser -Output "C:\temp\classTrib.json"
  ```
- Executar por thumbprint (não interativo):
  ```
  .\cff-consulta.ps1 -Thumbprint "C9456276E33693AA73DB8D4BA20222215260BF16" -StoreLocation CurrentUser -Output "C:\temp\classTrib.json"
  ```
- Habilitar console UTF‑8 (se quiser ver acentos) e filtrar certificados:
  ```
  .\cff-consulta.ps1 -Filter "empresa" -EnableUtf8Console -Output "C:\temp\classTrib.json"
  ```

O que esperar
- O script lista uma tabela compacta com: índice, nome/CN (acentos removidos por padrão), documento (CNPJ/CPF quando detectado), data de expiração, flag de chave privada e thumbprint completo.
- Você pode escolher pelo número da lista ou colar o thumbprint completo.
- A resposta HTTP é salva em UTF‑8 sem BOM no arquivo especificado.

Observações rápidas
- Se o certificado não tiver chave privada acessível, o script avisa; normalmente mTLS exige a chave privada.
- Para exibir corretamente acentos no console, use `-EnableUtf8Console` e um terminal que suporte UTF‑8 (alguns consoles Windows antigos podem ainda mostrar problemas).
- O script força TLS 1.2 para compatibilidade com o endpoint CFF.